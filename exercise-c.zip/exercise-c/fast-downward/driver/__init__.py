# -*- coding: utf-8 -*-

from .version import __version__
