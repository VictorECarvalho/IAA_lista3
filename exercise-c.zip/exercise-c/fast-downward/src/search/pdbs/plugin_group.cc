#include "../plugin.h"

namespace pdbs {
static PluginGroupPlugin _plugin(
    "heuristics_pdb",
    "Pattern Database Heuristics");
}
