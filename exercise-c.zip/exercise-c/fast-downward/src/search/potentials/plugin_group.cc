#include "../plugin.h"

namespace potentials {
static PluginGroupPlugin _plugin(
    "heuristics_potentials",
    "Potential Heuristics");
}
